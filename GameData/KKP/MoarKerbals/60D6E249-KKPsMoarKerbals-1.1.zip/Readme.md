================
MoarKerbals v1.1
================
This mod installs a Klone Bay that you can use to replicate new kerbals wherever you feel like.  It takes a fair amount of electricity, and when combined with USI's MKS mod or TAC Life Support, it will require biomatter as well.

There is a small chance for a freakish accident to occur, which can be disabled in the part's .cfg file, or you can just quicksave before kloning ;)

================
Installation
================
Just copy the GameData folder over to your Kerblal's install folder and enjoy.

License is CC 4.0 BY-NC-SA

DNA Icon made by Freepik from www.flaticon.com CC BY 3.0

Textures originally made by RoverDude distributed under the CC 4.0 BY-NC-SA, modified by me

================
Change Log
================
v1.1
-Twice as many parts as before!  Orbital station as well as ground station version.
-Textures adapted from RoverDude's parts, designed to fit in with his style
-Added success/failure sounds
v1.0
-Initial release